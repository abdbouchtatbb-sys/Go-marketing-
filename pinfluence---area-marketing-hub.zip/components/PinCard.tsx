import React, { useState } from 'react';
import { Heart, MoreHorizontal, Share2, ExternalLink } from 'lucide-react';
import { Pin } from '../types';

interface PinCardProps {
  pin: Pin;
}

export const PinCard: React.FC<PinCardProps> = ({ pin }) => {
  const [isHovered, setIsHovered] = useState(false);

  return (
    <div 
      className="relative mb-6 break-inside-avoid rounded-2xl overflow-hidden cursor-zoom-in group"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      <img 
        src={pin.imageUrl} 
        alt={pin.title} 
        className="w-full h-auto object-cover"
        loading="lazy"
      />
      
      {/* Overlay */}
      <div className={`absolute inset-0 bg-black/20 transition-opacity duration-200 ${isHovered ? 'opacity-100' : 'opacity-0'}`}>
        <div className="flex flex-col justify-between h-full p-3">
          <div className="flex justify-between items-start">
            <button className="text-white font-medium bg-red-600 hover:bg-red-700 px-4 py-2 rounded-full text-sm">
              Save
            </button>
            <div className="flex gap-2">
                 <button className="bg-white/90 p-2 rounded-full hover:bg-white text-gray-800 transition-colors">
                     <Share2 size={16} />
                 </button>
                 <button className="bg-white/90 p-2 rounded-full hover:bg-white text-gray-800 transition-colors">
                     <MoreHorizontal size={16} />
                 </button>
            </div>
          </div>
          
          <div className="flex justify-between items-center">
            <a 
                href="#" 
                className="bg-white/90 px-3 py-1.5 rounded-full flex items-center gap-2 hover:bg-white text-xs font-semibold text-gray-800 transition-colors truncate max-w-[70%]"
                onClick={(e) => e.stopPropagation()}
            >
                <ExternalLink size={12} />
                <span>pinfluence.app</span>
            </a>
          </div>
        </div>
      </div>

      {/* Generated Badge */}
      {pin.isGenerated && (
        <div className="absolute top-2 left-2 bg-purple-600 text-white text-[10px] font-bold px-2 py-0.5 rounded-full shadow-sm z-10">
            GEMINI
        </div>
      )}
      
      {/* Metadata (Usually shown below the pin in feed, but inside hover in some views. We'll do below for standard feed) */}
      {!isHovered && (
          <div className="absolute bottom-0 inset-x-0 bg-gradient-to-t from-black/60 to-transparent p-4 pt-8">
              <h3 className="text-white text-sm font-semibold truncate">{pin.title}</h3>
              <p className="text-white/80 text-xs truncate">{pin.author}</p>
          </div>
      )}
    </div>
  );
};
