import React, { useState } from 'react';
import { Search, TrendingUp, MapPin, Loader2 } from 'lucide-react';
import { analyzeTrends } from '../services/geminiService';
import { Trend } from '../types';

export const TrendExplorer: React.FC = () => {
  const [location, setLocation] = useState('United States');
  const [trends, setTrends] = useState<Trend[]>([]);
  const [loading, setLoading] = useState(false);
  const [hasSearched, setHasSearched] = useState(false);

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!location) return;
    
    setLoading(true);
    setHasSearched(true);
    try {
      const results = await analyzeTrends(location);
      setTrends(results);
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="w-full max-w-6xl mx-auto px-4 py-8">
      <div className="bg-gradient-to-r from-pink-500 to-red-500 rounded-3xl p-8 mb-8 text-white relative overflow-hidden">
        <div className="relative z-10">
            <h2 className="text-3xl font-bold mb-4">Discover Local Trends</h2>
            <p className="text-white/90 mb-6 max-w-xl">
            Use Gemini with Google Search Grounding to find out what's trending in your specific marketing area right now.
            </p>
            
            <form onSubmit={handleSearch} className="flex gap-2 max-w-lg bg-white/20 p-2 rounded-full backdrop-blur-md">
                <div className="flex-1 flex items-center px-4 text-white placeholder-white/70">
                    <MapPin size={18} className="mr-2" />
                    <input 
                        type="text"
                        value={location}
                        onChange={(e) => setLocation(e.target.value)}
                        placeholder="Enter location (e.g., Austin, TX)"
                        className="bg-transparent border-none outline-none w-full placeholder-white/70 font-medium"
                    />
                </div>
                <button 
                    type="submit"
                    disabled={loading}
                    className="bg-white text-red-600 px-6 py-2 rounded-full font-bold hover:bg-gray-100 transition-colors flex items-center gap-2"
                >
                    {loading ? <Loader2 className="animate-spin" size={18} /> : <Search size={18} />}
                    Scan
                </button>
            </form>
        </div>
        
        {/* Decorative background elements */}
        <div className="absolute top-0 right-0 w-64 h-64 bg-yellow-400 rounded-full mix-blend-multiply filter blur-3xl opacity-30 -translate-y-1/2 translate-x-1/4"></div>
        <div className="absolute bottom-0 right-20 w-64 h-64 bg-purple-600 rounded-full mix-blend-multiply filter blur-3xl opacity-30 translate-y-1/3"></div>
      </div>

      {loading && (
        <div className="flex flex-col items-center justify-center py-20 text-gray-500">
            <Loader2 className="animate-spin mb-4" size={40} />
            <p>Analyzing search data for {location}...</p>
        </div>
      )}

      {!loading && hasSearched && trends.length === 0 && (
          <div className="text-center py-20 text-gray-500">
              No trends found. Try a broader location.
          </div>
      )}

      {!loading && trends.length > 0 && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {trends.map((trend, idx) => (
                <div key={idx} className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 hover:shadow-md transition-shadow">
                    <div className="flex justify-between items-start mb-4">
                        <div className="bg-green-100 text-green-700 font-bold px-3 py-1 rounded-full text-xs flex items-center gap-1">
                            <TrendingUp size={12} />
                            +{trend.growth}%
                        </div>
                        <span className="text-gray-400 text-xs font-mono">#{idx + 1}</span>
                    </div>
                    <h3 className="text-xl font-bold text-gray-900 mb-2">{trend.topic}</h3>
                    <p className="text-gray-600 text-sm leading-relaxed">{trend.description}</p>
                </div>
            ))}
        </div>
      )}
    </div>
  );
};
