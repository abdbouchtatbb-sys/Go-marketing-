import React, { useState } from 'react';
import { X, Sparkles, Loader2, Image as ImageIcon } from 'lucide-react';
import { generatePinConcepts, generatePinImage } from '../services/geminiService';
import { GeneratedPinConcept, Pin } from '../types';

interface CreateCampaignModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSavePins: (pins: Pin[]) => void;
}

export const CreateCampaignModal: React.FC<CreateCampaignModalProps> = ({ isOpen, onClose, onSavePins }) => {
  const [topic, setTopic] = useState('');
  const [area, setArea] = useState('');
  const [audience, setAudience] = useState('');
  const [loadingStep, setLoadingStep] = useState<'idle' | 'concepts' | 'images'>('idle');
  const [concepts, setConcepts] = useState<GeneratedPinConcept[]>([]);
  const [selectedConcepts, setSelectedConcepts] = useState<number[]>([]);

  if (!isOpen) return null;

  const handleGenerateConcepts = async () => {
    if (!topic || !area) return;
    setLoadingStep('concepts');
    try {
      const results = await generatePinConcepts(topic, area, audience || 'General');
      setConcepts(results);
    } catch (e) {
      alert("Failed to generate concepts. Check API key.");
    } finally {
      setLoadingStep('idle');
    }
  };

  const handleCreatePins = async () => {
    setLoadingStep('images');
    const newPins: Pin[] = [];

    // Filter to selected or all if none selected
    const conceptsToProcess = selectedConcepts.length > 0 
      ? concepts.filter((_, idx) => selectedConcepts.includes(idx))
      : concepts;

    try {
      for (const concept of conceptsToProcess) {
        // Generate image for each concept
        const imageUrl = await generatePinImage(concept.visualPrompt);
        
        newPins.push({
          id: Date.now().toString() + Math.random().toString(),
          title: concept.title,
          description: concept.description,
          imageUrl: imageUrl,
          tags: concept.tags,
          author: 'You',
          likes: 0,
          isGenerated: true
        });
      }
      onSavePins(newPins);
      onClose();
      // Reset
      setConcepts([]);
      setTopic('');
      setArea('');
    } catch (e) {
        console.error(e);
        alert("Error creating final pins");
    } finally {
      setLoadingStep('idle');
    }
  };

  const toggleConcept = (idx: number) => {
    setSelectedConcepts(prev => 
      prev.includes(idx) ? prev.filter(i => i !== idx) : [...prev, idx]
    );
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
      <div className="bg-white rounded-3xl w-full max-w-4xl max-h-[90vh] flex flex-col shadow-2xl overflow-hidden">
        
        {/* Header */}
        <div className="p-6 border-b border-gray-100 flex justify-between items-center">
          <h2 className="text-2xl font-bold text-gray-800">New Marketing Campaign</h2>
          <button onClick={onClose} className="p-2 hover:bg-gray-100 rounded-full text-gray-500">
            <X size={24} />
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-6 bg-gray-50">
          
          {/* Input Section */}
          <div className="bg-white p-6 rounded-2xl shadow-sm mb-8">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Product / Topic</label>
                <input 
                  type="text" 
                  value={topic}
                  onChange={(e) => setTopic(e.target.value)}
                  placeholder="e.g. Handmade Soap"
                  className="w-full px-4 py-2 border border-gray-200 rounded-xl focus:ring-2 focus:ring-red-500 focus:outline-none"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Target Area / Niche</label>
                <input 
                  type="text" 
                  value={area}
                  onChange={(e) => setArea(e.target.value)}
                  placeholder="e.g. Pacific Northwest, Eco-Conscious"
                  className="w-full px-4 py-2 border border-gray-200 rounded-xl focus:ring-2 focus:ring-red-500 focus:outline-none"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Target Audience</label>
                <input 
                  type="text" 
                  value={audience}
                  onChange={(e) => setAudience(e.target.value)}
                  placeholder="e.g. Millennials, Moms"
                  className="w-full px-4 py-2 border border-gray-200 rounded-xl focus:ring-2 focus:ring-red-500 focus:outline-none"
                />
              </div>
            </div>
            
            <button 
              onClick={handleGenerateConcepts}
              disabled={loadingStep !== 'idle' || !topic}
              className="w-full bg-red-600 hover:bg-red-700 text-white font-bold py-3 px-6 rounded-full flex items-center justify-center gap-2 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {loadingStep === 'concepts' ? (
                <>
                  <Loader2 className="animate-spin" /> Generating Ideas...
                </>
              ) : (
                <>
                  <Sparkles size={20} /> Generate Pin Concepts
                </>
              )}
            </button>
          </div>

          {/* Results Section */}
          {concepts.length > 0 && (
            <div className="space-y-4">
              <h3 className="text-lg font-semibold text-gray-800 px-2">Select Concepts to Create</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {concepts.map((concept, idx) => (
                  <div 
                    key={idx}
                    onClick={() => toggleConcept(idx)}
                    className={`
                      relative p-5 rounded-2xl border-2 cursor-pointer transition-all hover:shadow-md bg-white
                      ${selectedConcepts.includes(idx) ? 'border-red-500 ring-2 ring-red-100' : 'border-transparent'}
                    `}
                  >
                    <div className="absolute top-4 right-4 text-gray-400">
                        {selectedConcepts.includes(idx) && <div className="w-6 h-6 bg-red-500 rounded-full flex items-center justify-center text-white text-xs">✓</div>}
                    </div>
                    <div className="w-12 h-12 bg-gray-100 rounded-lg flex items-center justify-center mb-4 text-gray-400">
                        <ImageIcon size={24} />
                    </div>
                    <h4 className="font-bold text-gray-900 mb-2 leading-tight">{concept.title}</h4>
                    <p className="text-sm text-gray-600 mb-3 line-clamp-3">{concept.description}</p>
                    <div className="flex flex-wrap gap-1">
                      {concept.tags.slice(0, 3).map(tag => (
                        <span key={tag} className="text-[10px] uppercase tracking-wider bg-gray-100 text-gray-600 px-2 py-1 rounded-md">
                          #{tag}
                        </span>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        {concepts.length > 0 && (
          <div className="p-6 border-t border-gray-100 bg-white flex justify-end">
             <button 
              onClick={handleCreatePins}
              disabled={loadingStep !== 'idle'}
              className="bg-gray-900 hover:bg-black text-white font-bold py-3 px-8 rounded-full flex items-center gap-2 disabled:opacity-50"
            >
               {loadingStep === 'images' ? (
                <>
                  <Loader2 className="animate-spin" /> Designing Pins... (This may take a moment)
                </>
              ) : (
                <>
                  Create {selectedConcepts.length > 0 ? selectedConcepts.length : 'All'} Pins
                </>
              )}
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
