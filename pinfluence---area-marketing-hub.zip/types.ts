export interface Pin {
  id: string;
  title: string;
  description: string;
  imageUrl: string;
  tags: string[];
  author: string;
  likes: number;
  isGenerated?: boolean;
}

export interface GeneratedPinConcept {
  title: string;
  description: string;
  visualPrompt: string;
  tags: string[];
}

export interface Trend {
  topic: string;
  growth: number;
  description: string;
}

export type ViewMode = 'discover' | 'trends' | 'boards';
