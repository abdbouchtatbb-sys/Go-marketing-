import { Pin, Trend } from './types';

export const MOCK_PINS: Pin[] = [
  {
    id: '1',
    title: 'Minimalist Home Office',
    description: 'Create a serene workspace with these minimalist design tips.',
    imageUrl: 'https://picsum.photos/400/600',
    tags: ['Interior', 'Home Office', 'Minimalism'],
    author: 'Sarah Design',
    likes: 1205
  },
  {
    id: '2',
    title: 'Healthy Meal Prep',
    description: 'A week of healthy eating made easy with these prep containers.',
    imageUrl: 'https://picsum.photos/400/400',
    tags: ['Food', 'Health', 'Meal Prep'],
    author: 'FitLife',
    likes: 890
  },
  {
    id: '3',
    title: 'Summer Fashion Trends',
    description: 'Light linens and breezy cuts for the upcoming season.',
    imageUrl: 'https://picsum.photos/400/700',
    tags: ['Fashion', 'Summer', 'Style'],
    author: 'Vogue Daily',
    likes: 3400
  },
  {
    id: '4',
    title: 'DIY Garden Planters',
    description: 'Upcycle old containers into beautiful garden features.',
    imageUrl: 'https://picsum.photos/400/500',
    tags: ['DIY', 'Garden', 'Upcycling'],
    author: 'GreenThumb',
    likes: 560
  },
  {
    id: '5',
    title: 'Travel Photography Tips',
    description: 'Capture the moment perfectly with these golden hour tricks.',
    imageUrl: 'https://picsum.photos/400/300',
    tags: ['Photography', 'Travel', 'Tips'],
    author: 'LensMaster',
    likes: 2100
  },
  {
    id: '6',
    title: 'Coffee Shop Aesthetics',
    description: 'Best spots in Seattle for that moody coffee vibe.',
    imageUrl: 'https://picsum.photos/400/550',
    tags: ['Travel', 'Coffee', 'Aesthetic'],
    author: 'UrbanExplorer',
    likes: 120
  }
];

export const MOCK_TRENDS: Trend[] = [
  { topic: 'Eco-Friendly Packaging', growth: 120, description: 'Sustainable solutions for small businesses.' },
  { topic: 'Maximalist Decor', growth: 85, description: 'Bold colors and patterns are making a comeback.' },
  { topic: 'Slow Travel', growth: 60, description: 'Focusing on connection rather than sightseeing.' },
  { topic: 'Digital Wellness', growth: 45, description: 'Balancing screen time with nature.' },
];
