import { GoogleGenAI, Type, Schema } from "@google/genai";
import { GeneratedPinConcept, Trend } from '../types';

// Ensure API Key is available
const apiKey = process.env.API_KEY || '';
const ai = new GoogleGenAI({ apiKey });

// Helper to validate key presence before calls to avoid runtime crashes if not set
const checkApiKey = () => {
  if (!apiKey) {
    throw new Error("API Key is missing. Please set process.env.API_KEY.");
  }
};

export const generatePinConcepts = async (topic: string, area: string, audience: string): Promise<GeneratedPinConcept[]> => {
  checkApiKey();
  
  const schema: Schema = {
    type: Type.ARRAY,
    items: {
      type: Type.OBJECT,
      properties: {
        title: { type: Type.STRING, description: "Catchy title for the pin" },
        description: { type: Type.STRING, description: "Engaging SEO-friendly description" },
        visualPrompt: { type: Type.STRING, description: "A detailed prompt to generate an image for this pin" },
        tags: { type: Type.ARRAY, items: { type: Type.STRING } }
      },
      required: ["title", "description", "visualPrompt", "tags"]
    }
  };

  const prompt = `
    Generate 3 distinct Pinterest marketing pin concepts for the topic: "${topic}".
    Target Area/Context: "${area}".
    Target Audience: "${audience}".
    
    Ensure the ideas are visually distinct and optimized for high engagement (saves/clicks).
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
        responseSchema: schema,
        temperature: 0.7,
      }
    });

    const text = response.text;
    if (!text) return [];
    return JSON.parse(text) as GeneratedPinConcept[];
  } catch (error) {
    console.error("Error generating concepts:", error);
    throw error;
  }
};

export const generatePinImage = async (prompt: string): Promise<string> => {
  checkApiKey();
  
  // Using flash-image for speed/cost effectiveness in this demo
  const model = 'gemini-2.5-flash-image'; 
  
  try {
    const response = await ai.models.generateContent({
      model: model,
      contents: `Generate a high-quality, aesthetic, vertical Pinterest-style image. ${prompt}`,
    });

    // Extract image from response
    // For gemini-2.5-flash-image, we look for inlineData in the parts
    for (const candidate of response.candidates || []) {
      for (const part of candidate.content.parts) {
         if (part.inlineData && part.inlineData.data) {
           return `data:${part.inlineData.mimeType};base64,${part.inlineData.data}`;
         }
      }
    }
    
    throw new Error("No image data returned from model.");
  } catch (error) {
    console.error("Error generating image:", error);
    // Return a placeholder if generation fails to keep UI intact
    return `https://picsum.photos/seed/${encodeURIComponent(prompt)}/400/600`; 
  }
};

export const analyzeTrends = async (location: string): Promise<Trend[]> => {
  checkApiKey();

  const prompt = `
    What are the top 5 emerging consumer trends in ${location} right now related to lifestyle, home, or fashion?
    Use Google Search to find real-time data.
    Return a JSON array of objects with 'topic', 'growth' (estimated % increase, number only), and 'description'.
  `;

  const schema: Schema = {
      type: Type.ARRAY,
      items: {
          type: Type.OBJECT,
          properties: {
              topic: { type: Type.STRING },
              growth: { type: Type.NUMBER },
              description: { type: Type.STRING }
          },
          required: ["topic", "growth", "description"]
      }
  };

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash', // Use flash for tools
      contents: prompt,
      config: {
        tools: [{ googleSearch: {} }],
        responseMimeType: 'application/json',
        responseSchema: schema
      }
    });
    
    const text = response.text;
    if (!text) return [];
    return JSON.parse(text) as Trend[];
  } catch (error) {
    console.error("Error analyzing trends:", error);
    return [];
  }
};
