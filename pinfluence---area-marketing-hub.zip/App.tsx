import React, { useState } from 'react';
import { 
  Compass, 
  TrendingUp, 
  Plus, 
  LayoutGrid, 
  Search, 
  Bell, 
  MessageCircle,
  ChevronDown
} from 'lucide-react';
import { PinCard } from './components/PinCard';
import { CreateCampaignModal } from './components/CreateCampaignModal';
import { TrendExplorer } from './components/TrendExplorer';
import { Pin, ViewMode } from './types';
import { MOCK_PINS } from './constants';

const App: React.FC = () => {
  const [pins, setPins] = useState<Pin[]>(MOCK_PINS);
  const [viewMode, setViewMode] = useState<ViewMode>('discover');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  const handleSavePins = (newPins: Pin[]) => {
    setPins(prev => [...newPins, ...prev]);
    setViewMode('discover'); // Switch back to feed to see new pins
  };

  const filteredPins = pins.filter(pin => 
    pin.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
    pin.tags.some(tag => tag.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  return (
    <div className="min-h-screen bg-white">
      {/* Top Navigation Bar */}
      <nav className="fixed top-0 inset-x-0 z-40 bg-white h-[80px] flex items-center px-6 gap-4 shadow-sm">
        <div className="flex items-center gap-1 min-w-[180px]">
          <div className="w-8 h-8 bg-red-600 rounded-full flex items-center justify-center text-white font-bold text-lg">P</div>
          <span className="text-red-600 font-bold text-xl tracking-tight hidden md:block">PinFluence</span>
        </div>

        <div className="hidden md:flex gap-2">
            <button 
                onClick={() => setViewMode('discover')}
                className={`px-4 py-3 rounded-full font-semibold transition-colors ${viewMode === 'discover' ? 'bg-black text-white' : 'bg-transparent text-gray-900 hover:bg-gray-100'}`}
            >
                Home
            </button>
            <button 
                 onClick={() => setViewMode('trends')}
                 className={`px-4 py-3 rounded-full font-semibold transition-colors ${viewMode === 'trends' ? 'bg-black text-white' : 'bg-transparent text-gray-900 hover:bg-gray-100'}`}
            >
                Explore Trends
            </button>
            <button 
                 className="px-4 py-3 rounded-full font-semibold bg-transparent text-gray-900 hover:bg-gray-100 flex items-center gap-1"
            >
                Create <ChevronDown size={16} />
            </button>
        </div>

        <div className="flex-1 px-4">
            <div className="relative w-full max-w-3xl">
                <div className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-500">
                    <Search size={20} />
                </div>
                <input 
                    type="text" 
                    placeholder="Search for ideas, tags, or area trends..." 
                    className="w-full bg-gray-100 hover:bg-gray-200 focus:bg-white border-transparent focus:ring-4 focus:ring-blue-100 rounded-full py-3.5 pl-12 pr-4 transition-all outline-none font-medium text-gray-900"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                />
            </div>
        </div>

        <div className="flex items-center gap-2 text-gray-500">
            <button className="p-3 hover:bg-gray-100 rounded-full relative">
                <Bell size={24} />
                <span className="absolute top-2 right-2 w-2.5 h-2.5 bg-red-600 rounded-full border-2 border-white"></span>
            </button>
            <button className="p-3 hover:bg-gray-100 rounded-full">
                <MessageCircle size={24} />
            </button>
            <div className="w-8 h-8 bg-gray-200 rounded-full overflow-hidden ml-2">
                <img src="https://picsum.photos/seed/user/100/100" alt="Profile" />
            </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="pt-[100px] px-4 md:px-8 pb-10">
        
        {viewMode === 'discover' && (
           <>
             {/* Masonry Layout */}
             <div className="masonry-grid w-full max-w-[1800px] mx-auto">
                {filteredPins.map(pin => (
                    <PinCard key={pin.id} pin={pin} />
                ))}
             </div>
             
             {filteredPins.length === 0 && (
                 <div className="text-center py-20">
                     <p className="text-gray-500 text-lg">No pins found. Try creating a new campaign!</p>
                 </div>
             )}
           </>
        )}

        {viewMode === 'trends' && (
            <TrendExplorer />
        )}
      </main>

      {/* Floating Action Button for Mobile / Quick Create */}
      <div className="fixed bottom-8 right-8 z-30">
        <button 
            onClick={() => setIsModalOpen(true)}
            className="bg-black hover:bg-gray-800 text-white p-4 rounded-full shadow-lg hover:shadow-xl transition-all transform hover:scale-105 flex items-center gap-2"
        >
            <Plus size={24} />
            <span className="font-bold pr-2">Create</span>
        </button>
      </div>

      <CreateCampaignModal 
        isOpen={isModalOpen} 
        onClose={() => setIsModalOpen(false)} 
        onSavePins={handleSavePins} 
      />
    </div>
  );
};

export default App;
